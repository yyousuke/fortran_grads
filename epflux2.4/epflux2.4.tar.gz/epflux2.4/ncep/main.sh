#!/bin/csh
set ind = ~/beta-r03/epf/read
set nsyy = 2000
set nsmm = 01
set neyy = 2001
set nemm = 12
set AO = AO-
#
rm -f U V T
set target = ./map/${neyy}${AO}
 mkdir -p ${target}
 cp -f /dev/null ${target}/EPy.dat
 cp -f /dev/null ${target}/EPz.dat
 cp -f /dev/null ${target}/diver.dat
 cp -f /dev/null ${target}/fv.dat
 ln -s ${ind}/uwnd.${nsyy}${nsmm}-${neyy}${nemm}.bin U
 ln -s ${ind}/vwnd.${nsyy}${nsmm}-${neyy}${nemm}.bin V
 ln -s ${ind}/air.${nsyy}${nsmm}-${neyy}${nemm}.bin T
 make clean
 make
 foreach n ( 1 2 3 )
  echo "${n}" |./epflux
  cat EPy.dat >> ${target}/EPy.dat
  cat EPz.dat >> ${target}/EPz.dat
  cat diver.dat >> ${target}/diver.dat
  cat fv.dat >>  ${target}/fv.dat
 end
 cp -p ./grd/*.ctl ${target}
#rm -f U V T
exit
