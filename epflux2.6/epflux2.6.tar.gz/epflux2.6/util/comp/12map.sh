#!/bin/csh
echo $0 $1 $2 $3 $4 $5
set ifile1 = $1
set UTIL_HOME = ..
#
set ip = $2
set ista = $3
set iend = $4
set scale = $5
##set   ip = 17  # Choose level
##set ista = 1   # start record
##set iend = 2   # end record
##set scale = 1.0e+6
### set  scale = 1.0e-11
#
#
set par = 1
while ( ${par} <= 5 )
  if ( x$1 == "x" ) then
    echo "Usage: $0 ifile ip ista iend scale"
    exit 1
  else
    shift
  endif
@ par = ${par} + 1
end
#
#
make init > /dev/null
make link
#
set init_file = ${UTIL_HOME}/INIT
set nx = `awk '($1 == "NX"){print $3}' ${init_file} `
set ny = `awk '($1 == "NY"){print $3}' ${init_file} `
set np = `awk '($1 == "NP"){print $3}' ${init_file} `
set FC = `awk '($1 == "FC"){print $3}' ${init_file} `
set FFLAGS = `awk '($1 == "FFLAGS"){print $0}' ${init_file}|cut -d '=' -f2`
cat >! prog.f <<EOF
      implicit none
      integer, parameter :: nx=${nx}, ny=${ny}, np=${np}
      integer, parameter :: ista=${ista}, iend=${iend}, ip=${ip}
      integer :: i, j, k, it, nlen
      real(4) :: D1(nx,ny,np), P(np), x, Y(ny)
      real(8) :: scale, pi, ave(nx,ny,np)
      character(100) ::  a21
      pi = 4.0 * ATAN(1.0)
      nlen=nx*ny*np*4
      scale = ${scale}
      
!c+++ P
      open(10, file='P', status='old',                                  &
     & form='formatted', access='sequential')
!c+++ Y
      open(11, file='Y', status='old',                                  &
     & form='formatted', access='sequential')
!c+++ data
      a21 = '${ifile1}'
      open(21, file=a21, status='old',                                  &
     & form='unformatted', access='direct', recl=nlen)

!c
!c read
!c===
      do k = 1, np
        read(10, *, err=997) P(k)
!c      if (MOD(k,10).eq.0) write(6,*) 'P=', P(k)
      enddo

      do j = 1, ny
        read(11, *, err=998) Y(j)
!c      if (MOD(j,10).eq.0) write(6,*) 'Y =',Y(j)
      enddo
      ave = 0.0
      do it = ista, iend
        read(21, rec=it, err=999) D1
        ave = ave + DBLE( D1 )
      enddo  ! it
      ave = ave / DBLE(iend - ista + 1) * scale

      do j = 1, ny
        do i = 1, nx
          x = 360.0 / nx * (i-1)
          write(51,610) x, y(j), ave(i,j,ip)
        enddo
        x = 360.0
        write(51,610) x, y(j), ave(1,j,ip)
      enddo

      stop
  600 format(2f10.2,2f10.3)
  610 format(2f10.2,2(2x,1pe16.5))
  997 write(6,*) 'Error; DO NOT READ P...'
  998 write(6,*) 'Error; DO NOT READ Y...'
  999 write(6,*) 'Error; DO NOT READ DATA, REC=',it

      end
EOF
rm -f a.out output.gmt
${FC} ${FFLAGS}  prog.f 
./a.out
mv -f fort.51 output.gmt
rm -f prog.f a.out
rm -f *.o
make link-clean

exit 0
