#!/bin/csh
set UTIL_HOME = ..
#
# input and output files
set ifile1 = u.dat  # x-axis of vector 
set ifile2 = v.dat  # y-axis of vector 
set ifile3 = div.dat  # contour or shade
set ofile = diff.plumb.composite.ps
#
set ip = 17    # Choose level
set ista = 1   # start record
set iend = 1   # end record
set scale_v = 1.0e-3  # scale factor of vector
set scale_c = 1.0e+6  # scale factor of contour
set leg_spd = 400     # vector speed for legend
#
set cont = 50    # contour interval 
set anot = 100   # annotation interval
set min = -500   # minimum value of shade
set max =  500   # maximum value of shade
set minlat = 20  # maximum value of latitude
set title = ( 3 hPa Plumb Flux )
##set subtitle = ( Composite map of AO- )
set subtitle = ( AO+ - AO- )
#
set map = 0    # 0; no coastline, 1; draw coastline
#
set leg = 1    # 0; no legend, 1; draw legend
#
set cmode = 0  # 0; color, 1; gray
#
set run = 0    # 0; only draw  1; run parts and draw
#
#
make init > /dev/null
#
set init_file = ${UTIL_HOME}/INIT
set nx = `awk '($1 == "NX"){print $3}' ${init_file} `
set ny = `awk '($1 == "NY"){print $3}' ${init_file} `
set np = `awk '($1 == "NP"){print $3}' ${init_file} `
set FC = `awk '($1 == "FC"){print $3}' ${init_file} `
set FFLAGS = `awk '($1 == "FFLAGS"){print $0}' ${init_file}|cut -d '=' -f2`
#

if ( ${run} == 1 )  then
 (./12map.sh  ${ifile3} ${ip} ${ista} ${iend} ${scale_c} ) || exit 1
 (./13map.sh  ${ifile1} ${ifile2} ${ip} ${ista} ${iend} ${scale_v} ) || exit 1
endif

if (! -e output.gmt ) exit 1
if (! -e vector.gmt ) exit 1

#
# GMT
#
rm -f .gmt*
gmtset BASEMAP_TYPE PLAIN
gmtset PAPER_MEDIA a4

echo "3.5 7.5 18 0 4 2  ${title} " >! h5gmt.ymd
echo "3.5 7.2 12 0 4 2 ( ${subtitle} ) " >> h5gmt.ymd  
###echo "5.5 1.0 12 0 4 2 ${leg_spd} " >> h5gmt.ymd  
pstext h5gmt.ymd -R0/8.0/0/8.0 -Jx1 -P -K   >! output.ps

#blockmedian output.gmt -R0/360/-90/90 -I2.5/2.5 -H0 -L -V >! tmp01
blockmean output.gmt -R0/360/-90/90 -I2.5/2.5 -H0 -L -V >! tmp01
surface  tmp01 -Gh500.cdf -I2.5/2.5 -R0/360/-90/90 -L -V
set x_mov = `echo ${minlat} | awk '{print 0.5+$1/40}' `
set y_mov = `echo ${minlat} | awk '{print 1.0+$1/20}' `
##psbasemap -R0/360/${minlat}/90 -Ja180/90/3.0/0 -Bg30/20g20 -Y1.0 -X0.5 -P -O -K  >> output.ps
psbasemap -R0/360/${minlat}/90 -Ja180/90/3.0/0 -Bg30/20g20 -Y${y_mov} -X${x_mov} -P -O -K  >> output.ps
#
set ctable = polar # polar cool rainbow
set makecptflag =
if ( ${cmode} == 1) then
  set ctable = gray
  set min = -0
  set makecptflag = -I
endif
@ c_int = ${cont} / 2
makecpt -C${ctable} -T${min}/${max}/${c_int} -Z ${makecptflag} >! map.cpt
echo "makecpt -C${ctable} -T${min}/${max}/${c_int} -Z "

#makecpt -Cpolar -T-500/500/25 -Z >! map.cpt
#makecpt -Ccool -T-200/200/25 -Z >! map.cpt
#makecpt -Cpolar -T-200/200/25 -Z >! map.cpt
#makecpt -Cgray  -T-0/200/25 -l -Z >! map.cpt
#makecpt -Ccool -T-200/-25/25 -Z >! map1.cpt
#makecpt -Chot -T25/200/25 -Z -I >! map2.cpt
#makecpt -Crainbow -T-200/200/25 -Z >! map.cpt
#
grdimage h500.cdf -Ja -R -Cmap.cpt -P -K -O -V >> output.ps

if ( ${map} == 1 ) pscoast -R -Ja -B  -W1 -Dc -P -O -K  >> output.ps

grdcontour h500.cdf -R -Ja -B -C${cont} -A${anot}f7 -L-10000/0 -Wa2t10_10:0  -Wc2t10_10:0 -P -O -K -V >> output.ps
grdcontour h500.cdf -R -Ja -B -C${cont} -A${anot}f7 -L0/10000 -Wa2 -Wc2 -P -K -O  -V >> output.ps

#psxy vector.gmt -R -Ja  -G255 -SV0.0/0.04/0.02/n0.03  -W2 -P -O -V>> output.ps
# color vector
#awk '($3 <= 90 || $3 >= 270){print $0}' vector.gmt | psxy -R -Ja  -G255 -SV0.0/0.04/0.02/n0.03  -W2/255/0/0 -P -K -O -V>> output.ps
#awk '($3 > 90 && $3 < 270){print $0}' vector.gmt | psxy -R -Ja  -G255 -SV0.0/0.04/0.02/n0.03  -W2/0/0/255 -P -O -V>> output.ps
psxy vector.gmt -R -Ja  -G255 -SV0.0/0.04/0.02/n0.03  -W4 -P -K -O -V  >> output.ps
#
if ( ${leg} == 1 ) then
set spd = `echo ${leg_spd} | awk '{print $1 * '${scale_v}' }' `
@ leg_lat = ${minlat} + 10
psxy -R -B720/360n -Ja  -G255 -SV0.0/0.04/0.02/n0.03  -W2/0 -X1.8 -Y-0.3 -P -K -O -V>> output.ps <<EOF
##180 10 90 ${spd}
180 ${leg_lat} 90 ${spd}
EOF
@ leg_lat = ${leg_lat} + 1
pstext -R -Ja -P -K -O   >> output.ps <<EOF
183 ${leg_lat} 12 0 4 2 ${leg_spd} 
EOF
endif
#
pstext /dev/null -R -Jx1 -P -O   >> output.ps
#
rm -f .gmt*
rm -f h500.cdf  h5gmt.ymd
rm -f map.cpt  tmp01
mv -f output.ps ${ofile}
# echo graphics ended
#gs ${ofile}

#
exit
