#! /bin/csh
echo $0 $1 $2 $3 $4 $5 $6
set ifile1 = $1
set ifile2 = $2
#
set UTIL_HOME = ..
#
set   ip = $3
set ista = $4
set iend = $5
set scale = $6
##set   ip = 17  # Choose level
##set ista = 1   # start record
##set iend = 2   # end record
##set scale = 1.0e+0
##set arrow = 0.00500
set arrow = 1.00000
#
#
set par = 1
while ( ${par} <= 6 )
  if ( x$1 == "x" ) then
    echo "Usage: $0 ifile ip ista iend scale"
    exit 1
  else
    shift
  endif
@ par = ${par} + 1
end
#
#
make init > /dev/null
make link
#
set init_file = ${UTIL_HOME}/INIT
set nx = `awk '($1 == "NX"){print $3}' ${init_file} `
set ny = `awk '($1 == "NY"){print $3}' ${init_file} `
set np = `awk '($1 == "NP"){print $3}' ${init_file} `
set FC = `awk '($1 == "FC"){print $3}' ${init_file} `
set FFLAGS = `awk '($1 == "FFLAGS"){print $0}' ${init_file}|cut -d '=' -f2`

cat >! prog.f <<EOF
      implicit none
      integer, parameter :: nx=${nx}, ny=${ny}, np=${np}
      integer, parameter :: ista=${ista}, iend=${iend}, ip=${ip}
      integer :: i, j, k, it, nlen
      real(4) :: D(nx,ny,np,2), P(np), x, Y(ny)
      real(8) :: scale, arrow, spd, dir, pi, ave(nx,ny,np,2)
      character(100) ::  a21, a22
      pi = 4.0 * ATAN(1.0)
      nlen=nx*ny*np*4
      scale = ${scale}
      arrow = ${arrow}
      
!c+++ P
      open(10, file='P', status='old',                                  &
     & form='formatted', access='sequential')
!c+++ Y
      open(11, file='Y', status='old',                                  &
     & form='formatted', access='sequential')
!c+++ data1 
      a21 = '${ifile1}'
      open(21, file=a21, status='old',                                  &
     & form='unformatted', access='direct', recl=nlen)
!c+++ data2
      a22 = '${ifile2}'
      open(22, file=a22, status='old',                                  &
     & form='unformatted', access='direct', recl=nlen)

!c
!c read
!c===
      do k = 1, np
        read(10, *, err=997) P(k)
!cc     if (MOD(k,10).eq.0) write(6,*) 'P=', P(k)
      enddo

      do j = 1, ny
        read(11, *, err=998) Y(j)
!cc     if (MOD(j,10).eq.0) write(6,*) 'Y =',Y(j)
      enddo

      ave = 0.0
      do it = ista, iend
        read(21, rec=it, err=999) (((D(i,j,k,1),i=1,nx),j=1,ny),k=1,np)
        read(22, rec=it, err=999) (((D(i,j,k,2),i=1,nx),j=1,ny),k=1,np)
        ave = ave + DBLE( D )
      enddo  ! it
      ave = ave / DBLE( iend-ista+1 ) * scale

      do j = 1, ny
        do i = 1, nx
          x = 360.0 / NX * (i-1)
          spd = SQRT( ave(i,j,ip,1)**2 + ave(i,j,ip,2)**2 ) * arrow
          if ( (ave(i,j,ip,1).eq.0).and.(ave(i,j,ip,2).eq.0) ) then
             write(6,*) 'Warning: dir = 0',x,y(j)
            dir = 0
          else
            dir = ATAN2( ave(i,j,ip,1), ave(i,j,ip,2) ) / pi * 180.0
          endif
          write(52,610) x, y(j), ave(i,j,ip,1), ave(i,j,ip,2)
          if( y(j).le.10.0 ) goto 2
!c         if( (y(j).gt.10.0).and.(mod(i,2).eq.1) ) go to 2
!c         if( (y(j).gt.30.0).and.(mod(i,3).eq.1) ) go to 2
!c         if( (y(j).gt.60.0).and.(mod(i,5).eq.1) ) go to 2
!c         if( (y(j).gt.75.0).and.(mod(i,7).eq.1) ) go to 2
!c         if( (y(j).gt.80.0).and.(mod(i,9).eq.1) ) go to 2
          if( (y(j).gt.30.0).and.(mod(i,2).eq.1) ) go to 2
          if( (y(j).gt.60.0).and.(mod(i,3).eq.1) ) go to 2
          if( (y(j).gt.75.0).and.(mod(i,5).eq.1) ) go to 2
          write(51,610) x, y(j), dir, spd
!c         write(6,*) x, y(j), dir, spd
    2   enddo
        x = 360.0
        spd = sqrt( ave(1,j,ip,1)**2 + ave(1,j,ip,2)**2 ) * arrow
        if ( (ave(1,j,ip,1).eq.0).and.(ave(1,j,ip,2).eq.0) ) then
          dir = 0
        else
          dir = atan2( ave(1,j,ip,1), ave(1,j,ip,2) ) / pi * 180.0
        endif
        write(52,610) x, y(j), ave(1,j,ip,1), ave(1,j,ip,2)
        if(y(j).gt.10.0) then
          write(51,610) x, y(j), dir, spd
        endif
      enddo

      stop
  600 format(2f10.2,2f10.3)
  610 format(2f10.2,2(2x,1pe16.5))
  997 write(6,*) 'Error; DO NOT READ P...'
  998 write(6,*) 'Error; DO NOT READ Y...'
  999 write(6,*) 'Error; DO NOT READ DATA, REC=',it

      end
EOF
rm -f a.out vector.gmt
${FC} ${FFLAGS} prog.f 
./a.out
mv -f fort.51 vector.gmt
mv -f fort.52 plumb.gmt
rm -f prog.f a.out
rm -f *.o
make link-clean

exit
