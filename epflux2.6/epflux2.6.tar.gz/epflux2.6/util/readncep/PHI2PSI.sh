#!/bin/csh
set ivar = hgt
set ovar = psi

### set input and output file names ###
set ifile = ${ivar}.mon.mean.grads
set ofile = ${ovar}.mon.mean.grads
### set input and output file names ###


### set input and output directories ###
set ind  = `gawk '{print $2}' filedata.dat | head -2| tail -1`
set outd = `gawk '{print $2}' filedata.dat | head -2| tail -1`
### set input and output directories ###


### set variables automatically ###
set nsyy = `gawk '{print $1}' variable.dat | head -1`
set neyy = `gawk '{print $1}' variable.dat | head -2| tail -1`
set nsmm = `gawk '{print $2}' variable.dat | head -1`
set nemm = `gawk '{print $2}' variable.dat | head -2| tail -1`
set FC = `gawk '{print $2}' variable.dat | head -10| tail -1`
set OPT = `cat variable.dat | head -11| tail -1`
### set variables automatically ###

@ dimtime = ( ${neyy} - ${nsyy} ) * 12  + 1 + ${nemm} - ${nsmm}
echo ${dimtime}

set ista = 1
set iend = ${dimtime}
${FC} ${OPT} PHI2PSI.f -o a.out
#
rm -f Y PHI
rm -f fort.*
ln -s ${ind}/ydef.dat  Y
ln -s  ${ind}/${ifile} PHI
ln -s ${outd}/${ofile} fort.51
#
echo ${ista} ${iend}
echo ${ista} ${iend} | ./a.out
rm -f Y PHI
rm -f a.out
rm -f fort.*

exit
