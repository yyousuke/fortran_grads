#/bin/csh
set old = `pwd`
foreach var ( uwnd vwnd air omega hgt )
 set ind = ./${var}
 mkdir -p ${ind}
 cd ${ind}
 set syear = 1948
 set eyear = 2005
#
 set year = ${syear}
 while ( ${year} <= ${eyear} )
  if (! -e ${var}.${year}.nc) then
    echo 'get' ${var}.${year}.nc ...
    ~yousuke/bin/getncep.sh pressure 6hr ${var}.${year}.nc 
  endif
  @ year = ${year} + 1
 end
 cd ${old}
end
